package com.geekster.Employee.Address.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAddressProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
